var offset = 120;

function setup() {
  createCanvas(600, 600);
  background(25);
}

function draw() {
  if (keyIsPressed === true){
    fill ('orange');
  } else {
    fill ('red');
  }
  ellipse(mouseX,mouseY,25,32);
  if (mouseIsPressed) {
    rect(75, 75, 75, 75);
  } else {
    ellipse(120, 120, 120, 120);
  }
  ellipse (350, 350, 355, 355);
  fill('orange');
  ellipse(350, 350, 310, 310);
  strokeWeight(10);
  if (mouseX > 300){
    rect(300,300,120,120);
  } else { 
    ellipse(300,320, 40,40);
    ellipse(375,295, 40, 40);
    ellipse(420,400, 40, 40);}
  
  print(mouseIsPressed);
  
  for(var x =0; x<= width; x+= 50) {
    fill('green');
    ellipse(x+offset, 40, 20, 20); }
}



