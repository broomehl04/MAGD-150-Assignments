var song;
var video;
//Here I declared the variable for song and video so it is easier to call them
function preload(){
  song = loadSound("EgyptianPools.mp3");
  video = createVideo("movie.MOV");
  //here i preloaded the video and song so that they would run smoother
}
function setup() {
  createCanvas(600,600);
   song.play();
   video.play();
   video.loop();
  //here i put the loop so that the video would play contionusly.
   video(0,0);
}

function draw() {
  background(220);
  reverb = new p5.Reverb();
  reverb.process("EgyptianPools.mp3", 3, 2);
  reverb.song();
//here I put the actual functions so that they would work.
}