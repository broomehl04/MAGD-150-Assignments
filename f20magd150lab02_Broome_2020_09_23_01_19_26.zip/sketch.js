function setup() {
  createCanvas(400, 400);
}

function draw() {
  fill(0,0,255);
  background(25);
  colorMode(RGB, 255);
  let c = color(127,255,0);
  colorMode(RGB, 1);
  let myColor=c._getRed();
  text (myColor, 10, 10, 80, 80);
  noFill();
  strokeWeight(4);
  stroke(255,0,10, 0.3);
  colorMode(HSB, 255, 255, 255, 1);
  ellipse(100,200,300);
  fill(255,0,255);
  ellipse(125,170,190);
  triangle(300, 375,358, 320, 386, 375);
  arc(50,50,80,80,0, PI + QUARTER_PI);
  noFill();
  beginShape();
  vertex (300,110);
  vertex (335,110);
  vertex (360, 360);
  vertex (395,360);
  endShape(CLOSE);
}