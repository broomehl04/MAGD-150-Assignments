var ball = {
  x: 250, 
  y: 100,
  xspeed:2,
  yspeed:-4
}

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  background(0);
  stroke ('purple');
  strokeWeight(5);
  fill('pink');
  scale(1);
  rotate(-0.5);
  ellipse(ball.x, ball.y, 35,35);
  
  zero();
  one();
  collide();
  translate(0,mouseY);
  //This allows for the rectangles to move with the mouse to simulate a replica of the game Pong.
  rect(10,10,15,55);
  rect(375,10,15,55);

}

function zero() {
  ball.x = ball.x + ball.xspeed;
  ball.y = ball.y + ball.yspeed; }

  // this function moves the ball around canvas.

function one() {
  if (ball.x > height || ball.x < 0) {
    ball.xspeed = ball.xspeed * -1;
  }
  if(ball.y > width || ball.y < 0) {
    ball.yspeed = ball.yspeed * -1;
    
  // this function makes the ball bounce off the side of the canvas.
  
  }
}

function collide() {
  if (ball.x < 40)
    ball.xspeed = ball.xspeed * -1;
  if (ball.x > 360)
    ball.xspeed = ball.xspeed * -1;
  // This function makes the ball collide with the rectangles. 
}


