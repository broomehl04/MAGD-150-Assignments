let leafs1;
let leafs2;
var nums = [25,45,65,85]
var num = 42;
//here is where the class is created and it is called leafs to go with the nature theme
function setup() {
  createCanvas(600, 600);
  leafs1 = new leafs(300, 300, 400);
  leafs2 = new leafs (30,30,95);
}

function draw() {
  background(0);
  fill('green');
  stroke('green');
  ellipse(200, 250,100);
  ellipse(295,200,100);
  ellipse(275,200,100);
  ellipse(280,260,100);
  ellipse(200,200,100);
  //This is where i created stagnic leafs 
  stroke('brown');
  fill('brown');
  ellipse(300,300,nums[2],nums[2]);
  //Here i used the array to make a branch
  rect(200,200,100,280);
  leafs1.move();
  leafs1.show();
  leafs2.move();
  leafs2.show();
  //This is where the classes function is so that there is movement like leaves blowing away
}

class leafs{ 
  constructor () {
    this.x = 15;
    this.y = 5;
    this.r = 20;
    //here is where the constructor of the class is
  }
  move () {
    this.x = this.x + random (-2,2);
    this.y = this.y + random (-2,2); }
  
show() {
  stroke ('green');
  strokeWeight(3);
  fill('green');
  ellipse (this.x, this.y, this.r *2); 

  }
}